#ifndef __ITOA__
#define __ITOA__


void itoa(unsigned int number, char *str);


#endif
